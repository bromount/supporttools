<?php
define ("DEPLOYMENT_STATUS_INDEVELOPMENT", 'InDevelopment');
define ("DEPLOYMENT_STATUS_DEPLOYED", 'Deployed');

define ("GENDER_NEUTER", 'Neuter');
define ("GENDER_MASCULINE", 'Masculine');
define ("GENDER_FEMININE", 'Feminine');

define ("SHARING_MODEL_PRIVATE", 'Private');
define ("SHARING_MODEL_READ", 'Read');
define ("SHARING_MODEL_READWRITE", 'ReadWrite');

define ("STARTS_WITH_CONSONANT", 'Consonant');
define ("STARTS_WITH_VOWEL", 'Vowel');
define ("STARTS_WITH_SPECIAL", 'Special');

define ("TREAT_BLANKS_AS_BLANK", 'BlankAsBlank');
define ("TREAT_BLANKS_AS_ZERO", 'BlankAsZero');

?>